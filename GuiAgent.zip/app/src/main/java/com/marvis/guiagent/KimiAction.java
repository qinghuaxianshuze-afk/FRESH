package com.marvis.guiagent;

/**
 * Kimi 返回的操作动作数据类
 */
public class KimiAction {
    public String actionType;      // click, swipe, input, back, home, wait, finish
    public float x;               // 点击坐标 X
    public float y;               // 点击坐标 Y
    public float startX;          // 滑动起点 X
    public float startY;          // 滑动起点 Y
    public float endX;            // 滑动终点 X
    public float endY;            // 滑动终点 Y
    public long duration;         // 动作持续时间（毫秒）
    public String text;           // 输入的文字
    public String reasoning;      // 操作原因

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(actionType).append("] ");
        
        switch (actionType != null ? actionType.toLowerCase() : "") {
            case "click":
                sb.append(String.format("(%.0f, %.0f)", x, y));
                break;
            case "swipe":
                sb.append(String.format("(%.0f,%.0f)->(%.0f,%.0f)", startX, startY, endX, endY));
                break;
            case "input":
                sb.append(text != null ? text.substring(0, Math.min(text.length(), 20)) : "");
                break;
            default:
                break;
        }
        
        if (reasoning != null && !reasoning.isEmpty()) {
            sb.append(" | ").append(reasoning);
        }
        
        return sb.toString();
    }
}
