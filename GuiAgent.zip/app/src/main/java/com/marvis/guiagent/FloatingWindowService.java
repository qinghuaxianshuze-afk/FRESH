package com.marvis.guiagent;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 悬浮窗服务
 * 提供可拖动的悬浮窗，方便用户随时控制 Agent
 */
public class FloatingWindowService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    
    private float initialX;
    private float initialY;
    private float initialTouchX;
    private float initialTouchY;
    private boolean isMoving = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreateCreate();
        createFloatingWindow();
    }

    /**
     * 创建悬浮窗
     */
    private void createFloatingWindow() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // 创建悬浮窗布局
        floatingView = View.inflate(this, R.layout.floating_window, null);

        // 设置布局参数
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 100;

        // 将悬浮窗添加到窗口管理器
        windowManager.addView(floatingView, params);

        setupFloatingViewListeners();
    }

    /**
     * 设置悬浮窗事件监听
     */
    private void setupFloatingViewListeners() {
        // 整个悬浮窗的触摸事件（用于拖动）
        floatingView.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    isMoving = true;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (isMoving) {
                        params.x = (int) (initialX + (event.getRawX() - initialTouchX));
                        params.y = (int) (initialY + (event.getRawY() - initialTouchY));
                        windowManager.updateViewLayout(floatingView, params);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    isMoving = false;
                    return true;
            }
            return false;
        });

        // 停止任务按钮
        Button btnStop = floatingView.findViewById(R.id.btnFloatingStop);
        if (btnStop != null) {
            btnStop.setOnClickListener(v -> {
                AgentService service = AgentService.getInstance();
                if (service != null) {
                    service.stopTask();
                }
                Toast.makeText(this, "任务已停止", Toast.LENGTH_SHORT).show();
            });
        }

        // 关闭悬浮窗按钮
        Button btnClose = floatingView.findViewById(R.id.btnFloatingClose);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> stopSelf());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
    }
}
