package com.marvis.guiagent;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.util.Base64;

/**
 * GUI Agent 无障碍服务
 * 负责截屏、执行点击/滑动/输入等操作
 */
public class AgentService extends AccessibilityService {

    private static final String TAG = "AgentService";
    private static AgentService instance;
    
    private boolean isRunning = false;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private KimiClient kimiClient;
    private String currentTask = "";
    private int maxSteps = 50; // 最大操作步数，防止死循环
    private int currentStep = 0;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.d(TAG, "AgentService 已连接");
        kimiClient = new KimiClient();
        
        // 发送广播通知 MainActivity 服务已连接
        Intent intent = new Intent("com.marvis.guiagent.SERVICE_CONNECTED");
        sendBroadcast(intent);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 可以在这里监听事件，但主要逻辑由外部触发
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "AgentService 被中断");
    }

    public static AgentService getInstance() {
        return instance;
    }

    /**
     * 开始执行任务
     * @param task 任务描述
     * @param apiKey Kimi API Key
     */
    public void startTask(String task, String apiKey) {
        if (isRunning) {
            log("任务正在运行中...");
            return;
        }
        
        currentTask = task;
        currentStep = 0;
        isRunning = true;
        kimiClient.setApiKey(apiKey);
        
        log("开始执行任务: " + task);
        updateStatus("运行中...");
        
        // 启动任务循环
        executeTaskLoop();
    }

    /**
     * 停止当前任务
     */
    public void stopTask() {
        isRunning = false;
        currentStep = 0;
        log("任务已停止");
        updateStatus("已停止");
    }

    /**
     * 任务主循环：截屏 -> Kimi分析 -> 执行动作 -> 再截屏
     */
    private void executeTaskLoop() {
        if (!isRunning || currentStep >= maxSteps) {
            if (currentStep >= maxSteps) {
                log("达到最大步数限制，任务结束");
            }
            isRunning = false;
            updateStatus("已完成");
            return;
        }

        currentStep++;
        log("=== 第 " + currentStep + " 步 ===");

        // 1. 截取屏幕截图
        Bitmap screenshot = takeScreenshot();
        if (screenshot == null) {
            log("截屏失败，重试...");
            mainHandler.postDelayed(this::executeTaskLoop, 1000);
            return;
        }
        log("截屏成功");

        // 2. 将截图转为 Base64
        String base64Image = bitmapToBase64(screenshot);

        // 3. 调用 Kimi API 分析屏幕并获取操作指令
        kimiClient.analyzeScreen(base64Image, currentTask, new KimiClient.KimiCallback() {
            @Override
            public void onSuccess(KimiAction action) {
                if (action == null || action.actionType == null) {
                    log("Kimi 返回空指令，任务可能完成");
                    isRunning = false;
                    updateStatus("已完成");
                    return;
                }

                log("Kimi 指令: " + action.toString());

                // 4. 执行动作
                boolean success = executeAction(action);
                
                if (success) {
                    log("动作执行成功");
                    // 等待一段时间后继续下一轮循环（让界面有时间响应）
                    mainHandler.postDelayed(() -> executeTaskLoop(), getDelayTime(action));
                } else {
                    log("动作执行失败，继续尝试...");
                    mainHandler.postDelayed(() -> executeTaskLoop(), 1000);
                }
            }

            @Override
            public void onError(String error) {
                log("Kimi API 错误: " + error);
                mainHandler.postDelayed(() -> executeTaskLoop(), 2000); // 错误时等待更长时间
            }
        });
    }

    /**
     * 根据动作类型返回适当的延迟时间
     */
    private long getDelayTime(KimiAction action) {
        switch (action.actionType) {
            case "click":
                return 800; // 点击后等待 800ms
            case "swipe":
                return 1200; // 滑动后等待 1200ms
            case "input":
                return 600; // 输入后等待 600ms
            case "wait":
                return action.duration != null ? action.duration : 1500;
            case "finish":
                return 0;
            default:
                return 1000;
        }
    }

    /**
     * 截取当前屏幕
     */
    public Bitmap takeScreenshot() {
        try {
            // Android 10+ 使用 takeScreenshot API
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                TakeScreenshotResult result = takeScreenshot(
                    ScreenCapture.DISPLAY_ID_DEFAULT,
                    new ScreenCapture.ScreenshotHardwareBuffer()
                );
                
                if (result != null && result.getHardwareBuffer() != null) {
                    Bitmap bitmap = Bitmap.wrapHardwareBuffer(
                        result.getHardwareBuffer(),
                        result.getColorSpace()
                    ).getBitmap();
                    
                    // 关闭硬件缓冲区
                    result.getHardwareBuffer().close();
                    return bitmap;
                }
            }
            
            // 兼容旧版本：使用 MediaProjection 或其他方式
            // 这里简化处理，实际项目中需要实现完整的截屏逻辑
            return captureScreenLegacy();
            
        } catch (Exception e) {
            Log.e(TAG, "截屏异常", e);
            return null;
        }
    }

    /**
     * 旧版本兼容截屏方法
     */
    private Bitmap captureScreenLegacy() {
        try {
            // 通过无障碍服务获取根节点信息来辅助理解屏幕
            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode != null) {
                // 这里可以结合 UI Automator 等方式获取更详细的屏幕信息
                // 实际实现中建议使用 MediaProjection API 进行真实截屏
                Log.d(TAG, "获取到根节点信息");
            }
            return null; // 需要实际实现截屏功能
        } catch (Exception e) {
            Log.e(TAG, "旧版截屏失败", e);
            return null;
        }
    }

    /**
     * 执行 Kimi 返回的动作
     */
    private boolean executeAction(KimiAction action) {
        try {
            switch (action.actionType.toLowerCase()) {
                case "click":
                    return performClick(action.x, action.y);
                    
                case "swipe":
                    return performSwipe(
                        action.startX, action.startY,
                        action.endX, action.endY,
                        action.duration != null ? action.duration : 500
                    );
                    
                case "input":
                    return performInput(action.text);
                    
                case "back":
                    return performBack();
                    
                case "home":
                    return performHome();
                    
                case "wait":
                    // 等待已在 getDelayTime 中处理
                    return true;
                    
                case "finish":
                    log("Kimi 认为任务已完成");
                    isRunning = false;
                    updateStatus("已完成");
                    return true;
                    
                default:
                    log("未知动作类型: " + action.actionType);
                    return false;
            }
        } catch (Exception e) {
            Log.e(TAG, "执行动作失败", e);
            return false;
        }
    }

    /**
     * 点击指定坐标
     */
    public boolean performClick(float x, float y) {
        try {
            Path path = new Path();
            path.moveTo(x, y);
            
            GestureDescription.StrokeDescription stroke = 
                new GestureDescription.StrokeDescription(path, 0, 100);
            
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);
            
            boolean success = dispatchGesture(builder.build(), null, null);
            log("点击 (" + x + ", " + y + ") " + (success ? "成功" : "失败"));
            return success;
        } catch (Exception e) {
            Log.e(TAG, "点击失败", e);
            return false;
        }
    }

    /**
     * 滑动操作
     */
    public boolean performSwipe(float startX, float startY, float endX, float endY, long duration) {
        try {
            Path path = new Path();
            path.moveTo(startX, startY);
            path.lineTo(endX, endY);
            
            GestureDescription.StrokeDescription stroke = 
                new GestureDescription.StrokeDescription(path, 0, duration);
            
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);
            
            boolean success = dispatchGesture(builder.build(), null, null);
            log("滑动 (" + startX + "," + startY + ") -> (" + endX + "," + endY + ") " + 
                 (success ? "成功" : "失败"));
            return success;
        } catch (Exception e) {
            Log.e(TAG, "滑动失败", e);
            return false;
        }
    }

    /**
     * 输入文字
     */
    public boolean performInput(String text) {
        try {
            // 使用无障碍服务的粘贴功能
            android.content.ClipboardManager clipboard = 
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            android.content.ClipData clip = 
                android.content.ClipData.newPlainText("gui_agent_input", text);
            clipboard.setPrimaryClip(clip);
            
            // 模拟粘贴操作 (Ctrl+V)
            Path path = new Path();
            // 这里可以添加粘贴手势或使用其他方式
            
            log("已准备输入文字: " + text.substring(0, Math.min(text.length(), 20)) + "...");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "输入失败", e);
            return false;
        }
    }

    /**
     * 返回键
     */
    public boolean performBack() {
        return performGlobalAction(GLOBAL_ACTION_BACK);
    }

    /**
     * Home 键
     */
    public boolean performHome() {
        return performGlobalAction(GLOBAL_ACTION_HOME);
    }

    /**
     * Bitmap 转 Base64
     */
    private String bitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        // 压缩为 JPEG 格式，质量 80%，减小传输大小
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream);
        byte[] bytes = outputStream.toByteArray();
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return Base64.getEncoder().encodeToString(bytes);
        } else {
            return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
        }
    }

    /**
     * 日志输出
     */
    private void log(String message) {
        Log.d(TAG, message);
        Intent intent = new Intent("com.marvis.guiagent.LOG_MESSAGE");
        intent.putExtra("message", message);
        sendBroadcast(intent);
    }

    /**
     * 更新状态
     */
    private void updateStatus(String status) {
        Intent intent = new Intent("com.marvis.guiagent.STATUS_UPDATE");
        intent.putExtra("status", status);
        sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        isRunning = false;
        Log.d(TAG, "AgentService 已销毁");
    }
}
