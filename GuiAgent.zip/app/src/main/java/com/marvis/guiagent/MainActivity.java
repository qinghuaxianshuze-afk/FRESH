package com.marvis.guiagent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * 主界面 Activity
 * 提供用户交互界面，输入任务、启动/停止服务
 */
public class MainActivity extends AppCompatActivity {

    private EditText editApiKey;
    private EditText editTask;
    private TextView textStatus;
    private TextView textLog;
    private Button btnStartService;
    private Button btnExecuteTask;
    private Button btnStopTask;

    private boolean isServiceRunning = false;

    // 广播接收器：接收来自 AgentService 的消息
    private BroadcastReceiver messageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            
            if ("com.marvis.guiagent.LOG_MESSAGE".equals(action)) {
                String message = intent.getStringExtra("message");
                appendLog(message);
                
            } else if ("com.marvis.guiagent.STATUS_UPDATE".equals(action)) {
                String status = intent.getStringExtra("status");
                updateStatusUI(status);
                
            } else if ("com.marvis.guiagent.SERVICE_CONNECTED".equals(action)) {
                isServiceRunning = true;
                updateServiceButton();
                Toast.makeText(context, "无障碍服务已连接", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
        registerReceiver();
        
        // 检查并请求悬浮窗权限
        checkOverlayPermission();
    }

    /**
     * 初始化视图组件
     */
    private void initViews() {
        editApiKey = findViewById(R.id.editApiKey);
        editTask = findViewById(R.id.editTask);
        textStatus = findViewById(R.id.textStatus);
        textLog = findViewById(R.id.textLog);
        btnStartService = findViewById(R.id.btnStartService);
        btnExecuteTask = findViewById(R.id.btnExecuteTask);
        btnStopTask = findViewById(R.id.btnStopTask);

        textLog.setMovementMethod(new ScrollingMovementMethod());
    }

    /**
     * 设置按钮监听器
     */
    private void setupListeners() {
        // 启动/停止服务按钮
        btnStartService.setOnClickListener(v -> toggleAccessibilityService());

        // 执行任务按钮
        btnExecuteTask.setOnClickListener(v -> executeTask());

        // 停止任务按钮
        btnStopTask.setOnClickListener(v -> stopCurrentTask());
    }

    /**
     * 注册广播接收器
     */
    private void registerReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.marvis.guiagent.LOG_MESSAGE");
        filter.addAction("com.marvis.guiagent.STATUS_UPDATE");
        filter.addAction("com.marvis.guiagent.SERVICE_CONNECTED");
        registerReceiver(messageReceiver, filter);
    }

    /**
     * 切换无障碍服务状态
     */
    private void toggleAccessibilityService() {
        if (isServiceRunning) {
            // 服务已在运行，可以在这里添加停止逻辑
            Toast.makeText(this, "请到系统设置中关闭无障碍服务", Toast.LENGTH_LONG).show();
            openAccessibilitySettings();
        } else {
            // 打开系统无障碍设置页面让用户手动开启
            openAccessibilitySettings();
            Toast.makeText(this, "请在设置中开启 GUI Agent 无障碍服务", Toast.LENGTH_LONG).show());
        }
    }

    /**
     * 打开系统无障碍设置页面
     */
    private void openAccessibilitySettings() {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(intent);
    }

    /**
     * 检查悬浮窗权限
     */
    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && 
            !Settings.canDrawOverlays(this)) {
            
            // 请求悬浮窗权限
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                       Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    /**
     * 执行任务
     */
    private void executeTask() {
        String apiKey = editApiKey.getText().toString().trim();
        String task = editTask.getText().toString().trim();

        if (apiKey.isEmpty()) {
            Toast.makeText(this, "请输入 Kimi API Key", Toast.LENGTH_SHORT).show();
            return;
        }

        if (task.isEmpty()) {
            Toast.makeText(this, "请输入任务目标", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isServiceRunning) {
            Toast.makeText(this, "请先启动无障碍服务", Toast.LENGTH_SHORT).show();
            return;
        }

        // 调用 AgentService 执行任务
        AgentService service = AgentService.getInstance();
        if (service != null) {
            service.startTask(task, apiKey);
        } else {
            Toast.makeText(this, "无障碍服务未就绪", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 停止当前任务
     */
    private void stopCurrentTask() {
        AgentService service = AgentService.getInstance();
        if (service != null) {
            service.stopTask();
        }
    }

    /**
     * 追加日志信息
     */
    private void appendLog(String message) {
        String currentTime = java.text.DateFormat.getTimeInstance().format(new java.util.Date());
        String logLine = "[" + currentTime + "] " + message + "\n";
        textLog.append(logLine);
        
        // 自动滚动到底部
        final int scrollAmount = textLog.getLayout().getLineTop(textLog.getLineCount()) - textLog.getHeight();
        if (scrollAmount > 0) {
            textLog.scrollTo(0, scrollAmount);
        }
    }

    /**
     * 更新状态显示
     */
    private void updateStatusUI(String status) {
        textStatus.setText(status);
        
        if ("运行中...".equals(status)) {
            textStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else if ("已停止".equals(status)) {
            textStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        } else {
            textStatus.setTextColor(getResources()..getColor(android.R.color.darker_gray));
        }
    }

    /**
     * 更新服务按钮状态
     */
    private void updateServiceButton() {
        btnStartService.setText(isServiceRunning ? R.string.stop_service : R.string.start_service);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(messageReceiver);
    }
}
