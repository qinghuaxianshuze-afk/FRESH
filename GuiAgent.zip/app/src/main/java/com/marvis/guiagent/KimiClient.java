package com.marvis.guiagent;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Kimi 视觉模型 API 客户端
 * 负责与 Moonshot API 通信，发送截图并获取操作指令
 */
public class KimiClient {

    private static final String TAG = "KimiClient";
    private static final String API_URL = "https://api.moonshot.cn/v1/chat/completions";
    
    private String apiKey = "";
    private OkHttpClient client;
    
    // 系统提示词：指导 Kimi 如何分析屏幕并返回操作指令
    private static final String SYSTEM_PROMPT = 
        "你是一个手机 GUI 操作助手。用户会给你一张手机屏幕截图和任务目标，" +
        "你需要分析当前屏幕内容，并决定下一步要执行的操作。\n\n" +
        
        "你必须严格按照以下 JSON 格式返回操作指令（不要包含其他文字）：\n" +
        "{\n" +
        "  \"actionType\": \"click|swipe|input|back|home|wait|finish\",\n" +
        "  \"x\": 点击的X坐标（仅click时需要）,\n" +
        "  \"y\": 点击的Y坐标（仅click时需要）,\n" +
        "  \"startX\": 滑动起点X（仅swipe时需要）,\n" +
        "  \"startY\": 滑动起点Y（仅swipe时需要）,\n" +
        "  \"endX\": 滑动终点X（仅swipe时需要）,\n" +
        "  \"endY\": 滑动终点Y（仅swipe时需要）,\n" +
        "  \"duration\": 动作持续时间毫秒（可选，默认500-1500）,\n" +
        "  \"text\": 要输入的文字（仅input时需要）,\n" +
        "  \"reasoning\": \"简短说明为什么执行这个操作\"\n" +
        "}\n\n" +

        "动作类型说明：\n" +
        "- click: 点击屏幕上的某个位置\n" +
        "- swipe: 从一个位置滑动到另一个位置\n" +
        "- input: 在输入框中输入文字（会先点击再粘贴）\n" +
        "- back: 按返回键\n" +
        "- home: 按Home键回到桌面\n" +
        "- wait: 等待一段时间让页面加载\n" +
        "- finish: 任务已完成\n\n" +

        "重要规则：\n" +
        "1. 坐标值必须是数字类型\n" +
        "2. 坐标基于屏幕分辨率，通常手机宽度1080或1440像素\n" +
        "3. 每次只返回一个操作\n" +
        "4. 如果任务已经完成，返回 actionType: 'finish'\n" +
        "5. 如果需要等待页面加载，返回 actionType: 'wait'\n" +
        "6. 分析时要考虑当前界面状态和任务目标的匹配度";

    public KimiClient() {
        client = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * 分析屏幕截图并获取操作指令
     * @param base64Image Base64 编码的屏幕截图
     * @param task 当前任务描述
     * @param callback 回调接口
     */
    public void analyzeScreen(String base64Image, String task, KimiCallback callback) {
        if (apiKey == null || apiKey.isEmpty()) {
            callback.onError("API Key 未设置");
            return;
        }

        new Thread(() -> {
            try {
                JSONObject requestBody = buildRequestBody(base64Image, task);
                Request request = buildRequest(requestBody);
                
                Response response = client.newCall(request).execute();
                
                if (!response.isSuccessful()) {
                    callback.onError("HTTP 错误: " + response.code());
                    return;
                }

                String responseBody = response.body().string();
                KimiAction action = parseResponse(responseBody);
                
                callback.onSuccess(action);
                
            } catch (IOException e) {
                Log.e(TAG, "网络请求失败", e);
                callback.onError("网络请求失败: " + e.getMessage());
            } catch (Exception e) {
                Log.e(TAG, "解析响应失败", e);
                callback.onError("解析失败: " + e.getMessage());
            }
        }).start();
    }

    /**
     * 构建请求体
     */
    private JSONObject buildRequestBody(String base64Image, String task) throws Exception {
        JSONObject json = new JSONObject();
        
        json.put("model", "moonshot-v1-8k-vision"); // 使用视觉模型
        json.put("temperature", 0.1); // 低温度以获得更确定性的输出
        json.put("max_tokens", 500);

        // 构建消息数组
        JSONArray messages = new JSONArray();

        // 系统消息
        JSONObject systemMessage = new JSONObject();
        systemMessage.put("role", "system");
        systemMessage.put("content", SYSTEM_PROMPT);
        messages.put(systemMessage);

        // 用户消息（包含图片）
        JSONObject userMessage = new JSONObject();
        userMessage.put("role", "user");

        // 内容可以是文本+图片的多模态消息
        JSONArray contentArray = new JSONArray();

        // 文本部分
        JSONObject textPart = new JSONObject();
        textPart.put("type", "text");
        textPart.put("text", "当前任务：" + task + "\n请分析这张屏幕截图，告诉我下一步该做什么操作。");
        contentArray.put(textPart);

        // 图片部分
        JSONObject imagePart = new JSONObject();
        imagePart.put("type", "image_url");
        JSONObject imageUrl = new JSONObject();
        imageUrl.put("url", "data:image/jpeg;base64," + base64Image);
        imagePart.put("image_url", imageUrl);
        contentArray.put(imagePart);

        userMessage.put("content", contentArray);
        messages.put(userMessage);

        json.put("messages", messages);

        return json;
    }

    /**
     * 构建 HTTP 请求
     */
    private Request build(JSONObject requestBody) throws Exception {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(requestBody.toString(), JSON);

        return new Request.Builder()
            .url(API_URL)
            .addHeader("Authorization", "Bearer " + apiKey)
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build();
    }

    /**
     * 解析 API 响应
     */
    private KimiAction parseResponse(String responseBody) throws Exception {
        JSONObject responseJson = new JSONObject(responseBody);
        
        JSONArray choices = responseJson.getJSONArray("choices");
        if (choices.length() == 0) {
            throw new Exception("无返回结果");
        }

        JSONObject choice = choices.getJSONObject(0);
        JSONObject message = choice.getJSONObject("message");
        String content = message.getString("content").trim();

        Log.d(TAG, "Kimi 原始回复: " + content);

        // 尝试从回复中提取 JSON
        try {
            // 直接解析整个内容为 JSON
            JSONObject actionJson = new JSONObject(content);
            return parseKimiAction(actionJson);
        } catch (Exception e) {
            // 如果直接解析失败，尝试提取 JSON 部分
            int startIndex = content.indexOf("{");
            int endIndex = content.lastIndexOf("}");
            
            if (startIndex >= 0 && endIndex > startIndex) {
                String jsonStr = content.substring(startIndex, endIndex + 1);
                JSONObject actionJson = new JSONObject(jsonStr);
                return parseKimiAction(actionJson);
            }
            
            throw new Exception("无法从回复中提取有效的操作指令: " + content);
        }
    }

    /**
     * 解析 Kimi 返回的动作对象
     */
    private KimiAction parseKimiAction(JSONObject json) throws Exception {
        KimiAction action = new KimiAction();
        
        action.actionType = json.optString("actionType", null);
        action.x = (float) json.optDouble("x", -1);
        action.y = (float) json.optDouble("y", -1);
        action.startX = (float) json.optDouble("startX", -1);
        action.startY = (float) json.optDouble("startY", -1);
        action.endX = (float) json.optDouble("endX", -1);
        action.endY = (float) json.optDouble("endY", -1);
        action.duration = json.optLong("duration", 500);
        action.text = json.optString("text", null);
        action.reasoning = json.optString("reasoning", "");

        if (action.actionType == null || action.actionType.isEmpty()) {
            throw new Exception("缺少 actionType 字段");
        }

        return action;
    }

    /**
     * 回调接口
     */
    public interface KimiCallback {
        void onSuccess(KimiAction action);
        void onError(String error);
    }
}
